import { Component } from '@angular/core';

@Component({
    selector: `orilla`,
    templateUrl:'./second.component.html',
    styleUrls:['./second.component.css']
})

export class OrillaComponent{
    IO: string='kuya meryenda @ lobby';
}